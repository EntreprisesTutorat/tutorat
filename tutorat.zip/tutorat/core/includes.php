<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require ROOT.DS.'config'.DS.'conf.php';
require 'Router.php';
require 'Request.php';
require 'Dispatcher.php';
require 'Controller.php';
require 'Model.php';
require 'Session.php';
