<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AccueilController
 *
 * @author valou
 */
class AccueilController extends Controller {
    
    function accueil(){
        //Méthode vide car on n'a pas de traitement de données pour cette vue
    }
}
